# Definisi kelas dasar Vehicle
class Vehicle:
    def __init__(self, merk, tahun, warna):
        self.merk = merk
        self.tahun = tahun
        self.warna = warna

    def tampilan_info(self):
        print(f"mert: {self.merk}")
        print(f"tahun: {self.tahun}")
        print(f"warna: {self.warna}")

# Definisi kelas turunan car yang mewarisi dari vihicle
class car(Vehicle):
    def __init__(self, merk, tahun,warna, model):
        # Panggil kontruktor kelas dasar 
        super().__init__(merk, tahun, warna)
        self.model = model

    def tampilkan_info(self):
        # panggil metode kelas dasar untuk menampilakan info kendaraan
        super().tampilan_info()
        print(f"model: {self.model}")

# Program utama
if __name__ == "__main__":
    Car = car("Toyota", 2022, "Merah", "Camry")

    print("info kendaraan: ")
    Car.tampilan_info()