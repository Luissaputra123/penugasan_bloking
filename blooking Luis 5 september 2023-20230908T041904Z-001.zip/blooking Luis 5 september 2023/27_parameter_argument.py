#membuat function dengan parameter
def my_function(fname):
    print(fname + " Refsnes")

#memanggil function dengan arguments
my_function("Emil")
my_function("Tobias")
my_function("Linus")