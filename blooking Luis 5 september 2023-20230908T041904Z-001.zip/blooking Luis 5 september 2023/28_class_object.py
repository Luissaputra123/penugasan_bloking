#membuat class
class MyClass:
  x = 5 

    #membuat objek
p1 = MyClass()

#mencetak nilai var x pada class MyClass
print(p1.x)