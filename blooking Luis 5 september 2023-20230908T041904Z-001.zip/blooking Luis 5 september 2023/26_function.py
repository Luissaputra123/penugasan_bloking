#membuat function
def my_function():
  print("Hello from a function")

#memanggil function
my_function()