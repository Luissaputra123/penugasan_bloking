# Definisikan kelas Contact
class Contact:
    def __init__(self, nama, nomor_telepon, email):
        self. nama = nama
        self. nomor_telepon = nomor_telepon
        self. email = email

        def tampilan_info(self):
            print(f"nama: {self. nama}")
            print(f"nomor_telepon: {self. nomor_telopn}")
            print(f"email: {self. email}")
            print()

# Definisi kelas AddressBook untuk mengolah daftar kotak
class AddressBook:
    def __init__(self):
        self.daftar_kontak = []

    def tambah_kontak(self, kontak):
        self.daftar_kontak.append(kontak)

    def tampilan_semua_kontak(self):
        print("Daftar Kontak:")
        for kontak in self.daftar_kontak:
            kontak.tampilkan_info()

# Program utama
if __name__ == "__main__":
    address_Book = AddressBook()

    while True:
        print("Menu")
        print("1. Tambah Kontak")
        print("2. Tampilkan Semua Kontak")
        print("3. Keluar")

        pilihan = input("Pilih menu (1, 2, 3): ")

        if pilihan == "1":
            nama = input("Nama: ")
            nomor_telepon = input("Nomor telepon: ")
            email = input("email: ")
            Kontak_baru = Contact(nama, nomor_telepon, email)
            address_Book.tambah_kontak(Kontak_baru)
        elif pilihan == "2":
            address_Book.tampilan_semua_kontak()
        elif pilihan == "3":
            break
        else:
            print("Pilihan tidak valid. Silakan pilih menu yang benar. ")
            